


package com.example.demo2.service;

import com.example.demo2.entity.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.support.SimpleJpaRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo2.repository.*;
import java.util.List;
import java.util.Optional;


@Service
@Transactional
public class MainService {

    @Autowired
    RestaurantRepository RestaurantRepository;

    @Autowired
    DishRepository DishRepository;


    public void test1(){
        int i1=1;
        RestaurantEntity shop = RestaurantRepository.findById(i1).get();
        if (shop != null)
        {
            System.out.println("---------------1、shop信息--------------------");
            System.out.println("餐厅编号：" + shop.getId());
            System.out.println("餐厅名称：" + shop.getName());
            //获取关联的身份证信息信息
            System.out.println("---------------2、food信息信息---------------");
            List<DishEntity> foodList = shop.getDishList();
            int length = foodList.size();
            if(length!=0)
            {

                for( DishEntity food : foodList){
                    System.out.println("食物编号" + food.getId());
                    System.out.println("食物名称" + food.getName());
                    List<ReviewEntity> reviewList = food.getReview();
                    for( ReviewEntity review : reviewList){
                        System.out.println("评论编号" + review.getId());
                        System.out.println("评论名称" + review.getContent());

                    }
                }

            }else{
                System.out.println("失败");
            }
        }


    }


}

