package com.example.demo2.bean;

public record User (

    String username,
    String password
){
public User(){this(null,null);}
}
