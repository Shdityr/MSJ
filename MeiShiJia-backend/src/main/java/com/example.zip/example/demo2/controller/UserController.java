package com.example.demo2.controller;

import com.example.demo2.service.UserService;
import com.example.demo2.bean.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo2.entity.UserEntity;

@RestController  //表明这是一个控制器类
//@RequestMapping("/index")   //处理 /article 路径下的请求
public class UserController {
    @Autowired  //将 ArticleService 服务注入到控制器中，用于处理文章相关的逻辑。
    UserService userService;

    @RequestMapping(value = "/login")  //将处理POST请求的URL映射到 addNewArticle 方法上。
    public String getUserById() {
//        User u
//        String id=user.id;

//        String password=u.password();
//        String usename= u.username();
        System.out.println("siuuuuuu");
        String password="123";
        String usename= "zsh";
        String a=userService.getUserById(usename);
        System.out.println(a);
        if (a.equals(password)) {
            System.out.println("yse!!!!!!!!!!!!");
            return "hello world!";
        } else {
            System.out.println("NO!!!!!!!!!!!!!!");
            return "hello world!";
        }
    }
    @RequestMapping(value = "/register")  //将处理POST请求的URL映射到 addNewArticle 方法上。
    @ResponseBody
    public String addNewUser(User u) {////这段代码定义了一个将文章添加到系统中的方法 addNewArticle。
        UserEntity userEntity = new UserEntity();
        String usename= u.username();
        String password= u.password();
        userEntity.setUsername(usename);
        userEntity.setPassword(password);
        System.out.println("11111111");
        int result = userService.addNewUser(userEntity);
        return "8888!";
    }

}
