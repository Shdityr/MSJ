package com.example.demo2.repository;

import com.example.demo2.entity.UserEntity;
import org.springframework.data.repository.CrudRepository;
import java.util.List;
public interface UserRepository extends CrudRepository<UserEntity, Long> {
    List<UserEntity> findByUsername(String username);
}
