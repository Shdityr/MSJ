
package com.example.demo2.entity;
import jakarta.persistence.*;
        import com.example.demo2.entity.RestaurantEntity;
import com.example.demo2.entity.ReviewEntity;
import java.util.List;
import jakarta.persistence.*;



@Entity
@Table(name = "b")
public class DishEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;
    private String image;
    private String name;
    private String store;
    private String rating;
    private float averagePrice;
    private String style;





    @OneToMany(mappedBy = "dish", cascade = CascadeType.ALL)
    private List<ReviewEntity> reviewList;


    @ManyToOne
    @JoinColumn(name = "restaurant_id")
    private RestaurantEntity restaurant;





    public int getId(){return id;}
    public String getImage(){return image;}
    public String getName(){return name;}
    public String getStore(){return store;}
    public String getRating(){return rating;}
    public float getAveragePrice(){return averagePrice;}
    public String getStyle(){return style;}

    public RestaurantEntity getRestaurant(){return restaurant;}
    public List<ReviewEntity> getReview(){return reviewList;}


//    public List<FoodEntity> geta(){return foodList;}

    //    public void setID(Long value){this.id = value;}
//    public void setUsername(String value){this.username = value;}
//    public void setPassword(String value){this.password = value;}


}


