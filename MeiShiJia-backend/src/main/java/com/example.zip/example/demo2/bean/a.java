package com.example.demo2.bean;


//public record a (
//
//        String name_a
//){
//    public a(){this(null);}
//}