

package com.example.demo2.controller;

import com.example.demo2.service.MainService;
import com.example.demo2.service.UserService;
import com.example.demo2.bean.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo2.entity.UserEntity;

@RestController  //表明这是一个控制器类
//@RequestMapping("/index")   //处理 /article 路径下的请求
public class MainController {
    @Autowired  //将 ArticleService 服务注入到控制器中，用于处理文章相关的逻辑。
    MainService mainService;

    @RequestMapping(value = "/main")  //将处理POST请求的URL映射到 addNewArticle 方法上。
    public void test() {
        System.out.println("yse!!!!!!!!!!!!");
        mainService.test1();

    }


}

