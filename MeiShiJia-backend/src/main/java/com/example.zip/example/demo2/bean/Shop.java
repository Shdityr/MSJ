package com.example.demo2.bean;

public record Shop() {
}
