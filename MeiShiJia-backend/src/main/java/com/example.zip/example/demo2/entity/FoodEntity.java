package com.example.demo2.entity;
import jakarta.persistence.*;
        import com.example.demo2.entity.ShopEntity;
import java.util.List;
import jakarta.persistence.*;



@Entity
@Table(name = "foods")
public class FoodEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String name;







    @ManyToOne
    @JoinColumn(name = "shop_id")
    private ShopEntity shop;





    public Long getId(){return id;}
    public String getName(){return name;}
    public ShopEntity getShop(){return shop;}

//    public List<FoodEntity> geta(){return foodList;}

    //    public void setID(Long value){this.id = value;}
//    public void setUsername(String value){this.username = value;}
//    public void setPassword(String value){this.password = value;}


}

