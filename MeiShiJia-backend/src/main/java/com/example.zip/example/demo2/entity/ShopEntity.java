package com.example.demo2.entity;
import jakarta.persistence.*;
import com.example.demo2.entity.FoodEntity;
import java.util.List;
import jakarta.persistence.*;



@Entity
@Table(name = "shops")
public class ShopEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String name;

    private String location;


    @OneToMany(mappedBy = "shop", cascade = CascadeType.ALL)
    private List<FoodEntity> foodList;




    public Long getId(){return id;}
    public String getName(){return name;}
    public String getLocation(){return location;}

    public List<FoodEntity> getFoodList(){return foodList;}

    //    public void setID(Long value){this.id = value;}
//    public void setUsername(String value){this.username = value;}
//    public void setPassword(String value){this.password = value;}


}
