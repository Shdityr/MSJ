package com.example.demo2.entity;
import jakarta.persistence.*;
import com.example.demo2.entity.aEntity;
import java.util.List;
@Entity
@Table(name = "Users")
public class UserEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String username;
    private String password;

    @OneToOne(cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH})
    @JoinColumn(name = "a_id")
    private aEntity a1;


    public Long getId(){return id;}
    public String getName(){return username;}
    public String getPassword(){return password;}

    public aEntity geta(){return a1;}

//    public void setID(Long value){this.id = value;}
    public void setUsername(String value){this.username = value;}
    public void setPassword(String value){this.password = value;}


}