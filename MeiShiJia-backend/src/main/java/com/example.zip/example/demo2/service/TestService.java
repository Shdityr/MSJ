


package com.example.demo2.service;

import com.example.demo2.entity.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.support.SimpleJpaRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.example.demo2.repository.UserRepository;
import com.example.demo2.entity.UserEntity;
import com.example.demo2.repository.*;
        import java.util.List;
import java.util.Optional;


@Service
@Transactional
public class TestService {

    @Autowired
    ShopRepository shopRepository;



    public void test1(){
        long i1=1;
        ShopEntity shop = shopRepository.findById(i1).get();
        if (shop != null)
        {
            System.out.println("---------------1、shop信息--------------------");
            System.out.println("餐厅编号：" + shop.getId());
            System.out.println("餐厅名称：" + shop.getName());
            //获取关联的身份证信息信息
            System.out.println("---------------2、food信息信息---------------");
            List<FoodEntity> foodList = shop.getFoodList();
            int length = foodList.size();
            if(length!=0)
            {

                for( FoodEntity food : foodList){
                    System.out.println("食物编号" + food.getId());
                    System.out.println("食物名称" + food.getName());
                }

            }else{
                System.out.println("失败");
            }
        }
//        List<UserEntity> p = userRepository.findByUsername(username);
//        //return p.get(0).getPassword();
//        if (!p.isEmpty()) {
//            return p.get(0).getPassword();
//        } else {
//            return "sb";
//        }

    }

//    public int addNewUser(UserEntity userEntity){
//        System.out.println("2222222222");
////        UserEntity u = new UserEntity();
////        long a=111L;
////        u.setID(a);
////        u.setUsername("222");
////        u.setPassword("333");
//        userRepository.save(userEntity);
//        System.out.println("3333333");
//        return 0;
//    }
}

