package com.example.demo2.entity;

import jakarta.persistence.*;
import jakarta.persistence.*;
import com.example.demo2.entity.aEntity;
import java.util.List;



@Entity
@Table(name = "a")
public class aEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String name_a;





    public Long getId(){return id;}
    public String getName(){return name_a;}


    //    public void setID(Long value){this.id = value;}
    public void setUsername(String name){this.name_a = name;}



}